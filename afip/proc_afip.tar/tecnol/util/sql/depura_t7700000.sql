set serveroutput on
set termout on
set feed on
set doc off
spool &1
exec U601.DEPURA_T7700000
spool off
exit
