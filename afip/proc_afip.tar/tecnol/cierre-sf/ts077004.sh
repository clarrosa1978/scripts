#!/usr/bin/ksh
###############################################################################
# Aplicacion.........: AFIP                                                   #
# Grupo..............: CIERRE-SF                                              #
# Autor..............: Gustavo Alonso                                         #
# Nombre del programa: ts077004.sh                                            #
# Nombre del JOB.....: TS077004                                               #
# Descripcion........:                                                        #
# Modificacion.......: 20/09/2018                                             #
###############################################################################
set -x

###############################################################################
###                            Variables                                    ###
###############################################################################

export FECHA=${1}
export PARAMETRO=${2}
export NOMBRE="ts077004"
export PATHAPL="/tecnol/cierre-sf"
export PATHLOG="/tecnol/cierre-sf/log"
export PATHPRG="/sfctrl/sfgv/bin"
export PROGRAMA="${PATHPRG}/${NOMBRE}"
export LOGSCRIPT="${PATHLOG}/${NOMBRE}.${FECHA}.log"

###############################################################################
###                            Funciones                                    ###
###############################################################################

autoload Enviar_A_Log
autoload Borrar
autoload Check_Par

###############################################################################
###                            Principal                                    ###
###############################################################################

Check_Par 2 $@
[ $? != 0 ] && exit 1
Enviar_A_Log "INICIO - Comienza la ejecucion." ${LOGSCRIPT}
if [ -x ${PROGRAMA} ]
then
	if [ ${PARAMETRO} = noin ]
	then	
		${PROGRAMA} ${PARAMETRO} ${FECHA}
		if [ $? = 0 ]
        	then
                	Enviar_A_Log "FINALIZACION - OK." ${LOGSCRIPT}
                	find ${PATHLOG} -name "${NOMBRE}.*.log" -mtime +7 -exec rm {} \;
                	exit 0
        	else
                	Enviar_A_Log "ERROR - Error durante la ejecucion ${PROGRAMA}." ${LOGSCRIPT}
                	Enviar_A_Log "FINALIZACION - CON ERRORES." ${LOGSCRIPT}
			exit 7
        	fi
        else            
		if [ ${PARAMETRO} = conc ]
		then
   			${PROGRAMA} ${PARAMETRO}
			if [ $? = 0 ] 
			then
                		Enviar_A_Log "FINALIZACION - OK." ${LOGSCRIPT}
                		find ${PATHLOG} -name "${NOMBRE}.*.log" -mtime +7 -exec rm {} \;
                		exit 0
			else
				Enviar_A_Log "ERROR - Error durante la ejecucion ${PROGRAMA}." ${LOGSCRIPT}
                		Enviar_A_Log "FINALIZACION - CON ERRORES." ${LOGSCRIPT}
			fi
		else
			Enviar_A_Log "ERROR - El parametro ingresado no es el esperado." ${LOGSCRIPT}
			Enviar_A_Log "FINALIZACION - CON ERRORES." ${LOGSCRIPT}
			exit 5
		fi
	fi
else
        Enviar_A_Log "ERROR - No hay permisos de ejecucion para ${PROGRAMA}." ${LOGSCRIPT}
       	Enviar_A_Log "FINALIZACION - CON ERRORES." ${LOGSCRIPT}
      	exit 88
fi
