#!/bin/ksh
###########################################################################################
#NOMBRE DEL SCRIPT: preparartlog.sh                                                       #
#DESCRIPCION: Determina, copia y comprime el tlog del dia de la fecha para poder          #
#             transmitirlo a Central                                                      #
#PARAMETROS: Recibe N� de sucursal en tres digitos y la fecha con formato yyyymmdd        #
#AUTOR: Cristian Larrosa                                                                  #
#FECHA DE MODIFICACION: 25-08-2003                                                        #
#FECHA DE MODIFICACION: 28-10-2011 - Cambio de compresion a gzip - CFL                    #
###########################################################################################
set -x
###########################################################################################
#                                     VARIABLES                                           #
###########################################################################################
FECHA=$1
SUCURSAL=$3
PATHAPL="/sfctrl/r"
ARCHORI="`ls -1rt ${PATHAPL}/rollo.????.${FECHA} 2>/dev/null`"
ARCHDES="${PATHAPL}/rollo.${SUCURSAL}.${FECHA}.tar.gz"

cd ${PATHAPL} ; export ARCHIVOS=`ls -1rt rollo.????.${FECHA}`

###########################################################################################
#                                     PRINCIPAL                                           #
###########################################################################################
if [ $# -eq 9 ] 
then
        if [ -s ${ARCHORI} ] 
        then
		tar cvfz $ARCHDES $ARCHIVOS
                if [ $? -ne 0 ]
                then
                	echo "\tFallo la compresion del archivo $ARCHDES"
                        exit 11
		else
			echo "Borro los archivos luego de compactarlos."
			rm -f $ARCHORI
                fi
        else
                echo "\tEl archivo no existe"
                exit 10
        fi
else
	echo "\tLa cantidad de parametros recibida debe ser 2 (Numero de sucursal y fecha yyyymmdd)\n"
        echo "\tEj: Prepararollo.sh 090 20181025"
        exit 32
fi
