set -x
##############################################################################
#
# Genera las listas completa y auxiliar de LOGS correspondientes al grupo
# de LOGS en proceso.
#
#
# exit status:
#    0  - OK
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  12/12/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

BKP_LOG=${3}
GRP_PROC=${15}
LOG_LIST=${16}
DB_LOG_LIST=${17}
LOG_QTY=${18}

typeset -i AUX1
typeset -i AUX2

if [ ! -s ${GRP_PROC} ]
then
	gen_log "--- Puntero de grupo de LOGS en proceso inexistente"
	gen_log "--- Se aborta el backup"
	exit 10
fi

GRP=`cat ${GRP_PROC}`

gen_log "Generando lista de LOGS del grupo ${GRP}"

let "AUX1 = GRP - 1"
let "AUX2 = AUX1 * LOG_QTY"
let "AUX2 = AUX2 + 1"

rm -f ${LOG_LIST}
if [ -f ${LOG_LIST} ]
then
	gen_log "--- No se pudo borrar la lista de LOGS"
	exit 10
fi

tail +${AUX2} ${DB_LOG_LIST} | head -${LOG_QTY} > ${LOG_LIST}

if [ ! -s ${LOG_LIST} ]
then
	gen_log "--- No se pudo generar la lista de LOGS"
	exit 10
fi

cp -pf ${LOG_LIST} ${LOG_LIST}.aux

diff ${LOG_LIST} ${LOG_LIST}.aux
if [ $? != 0 ]
then
	gen_log "--- No se pudo generar la lista auxiliar de LOGS"
	exit 10
fi

gen_log "Lista de LOGS del grupo ${GRP} generada OK"

exit 0



