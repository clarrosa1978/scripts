set -x
##############################################################################
#
# Controla que haya una cinta en la unidad correspondiente. Tiene en cuenta
# si la unidad de backup permite el cambio automatico de cintas.
#
#
# exit status:
#    0 - OK
#    1 - Error. No hay cinta en la unidad.
#
#
# Cesar Lopez  -  29/11/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

BKP_LOG=${3}
TAPE=${8}
JUKEBOX=${10}

typeset -i i
i=0

if [ ${JUKEBOX} = YES ]
then
	while [ i -lt 5 ]
	do
		mt -f ${TAPE} rewind
		if [ $? = 0 ]
		then
			exit 0
		fi
		sleep 45
		let "i = i + 1"
	done
	gen_log "--- La unidad no pudo cargar la siguiente cinta"
else
	while [ i -lt 5 ]
	do
		sleep 45
		mt -f ${TAPE} rewind
		if [ $? = 0 ]
		then
			exit 0
		fi
		let "i = i + 1"
	done
	gen_log "--- Cargar manualmente la siguiente cinta"
fi
exit 1



