set -x
##############################################################################
#
# Fin del backup. Copia el log del backup, las listas de tablespaces y logs
# procesados al directorio de la secuencia utilizada, dejando esta actualizada
# para el proximo backup.
#
#
# EXIT STATUS:
#    0    - OK
#    Otro - Ver mensaje de error.
#
#
# Cesar Lopez  -  17/12/2002
#
##############################################################################

BKP_LOG=${3}
TS_LIST=${4}
SEQ_DIR=${11}
DB_LOG_LIST=${17}

NEXT_SEQ=`ls -t ${SEQ_DIR} |tail -1`
if [ "x${NEXT_SEQ}" = "x" ]
then
	echo "El backup finalizo correctamente, pero no se pudo obtener la"
	echo "secuencia para actualizar"
	exit 10
fi

BASENAME=`basename ${BKP_LOG}`

cat ${BKP_LOG} | compress -f > ${SEQ_DIR}/${NEXT_SEQ}/${BASENAME}.Z
if [ $? != 0 ]
then
	echo "El backup finalizo correctamente, pero hubo un error copiando el log"
	echo "al directorio de secuencias. Controlar si esta se actualizo."
	exit 10
fi

touch ${SEQ_DIR}/${NEXT_SEQ}

cp -pf ${TS_LIST} ${SEQ_DIR}/${NEXT_SEQ}
if [ $? != 0 ]
then
	echo "El backup finalizo correctamente, y se actualizo la secuencia, pero"
	echo "hubo un error copiando la lista de TS al directorio de secuencias."
	exit 10
fi

cp -pf ${DB_LOG_LIST} ${SEQ_DIR}/${NEXT_SEQ}
if [ $? != 0 ]
then
	echo "El backup finalizo correctamente, y se actualizo la secuencia, pero"
	echo "hubo un error copiando la lista de LOGS al directorio de secuencias."
	exit 10
fi

touch ${SEQ_DIR}/${NEXT_SEQ}

exit 0



