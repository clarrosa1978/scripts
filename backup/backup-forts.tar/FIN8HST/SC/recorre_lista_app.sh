set -x
##############################################################################
#
# Genera el puntero de grupo de aplicaciones en proceso, a partir de la lista
# auxiliar de grupos de aplicaciones.
#
#
# exit status:
#    0  - OK
#    1  - OK. (no hay mas grupos de aplicaciones para procesar)
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  19/12/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

APP=${1}
DATE=${2}
BKP_LOG=${3}
TAPE=${8}
APP_LIST=${20}
APP_PROC=${21}

YYYY=`echo ${DATE} | cut -c 1-4`
MM=`echo ${DATE} | cut -c 5-6`
DD=`echo ${DATE} | cut -c 7-8`

if [ ! -f ${APP_LIST}.aux ]
then
	gen_log "--- Lista auxiliar de grupos de aplicaciones inexistente"
	gen_log "--- Se aborta el backup"
	exit 10
fi

if [ -s ${APP_LIST}.aux ]
then
	if [ -f ${APP_PROC} ]
	then
		cp -pf ${APP_PROC} ${APP_PROC}.bkp
		diff ${APP_PROC} ${APP_PROC}.bkp
		if [ $? != 0 ]
		then
			gen_log "--- No se pudo hacer copia del puntero de grupo de aplicaciones en proceso"
			exit 10
		fi
		rm -f ${APP_PROC}
		if [ -f ${APP_PROC} ]
		then
			gen_log "--- No se pudo borrar el puntero de grupo de aplicaciones en proceso"
			exit 10
		fi
	fi
	APP=`head -1 ${APP_LIST}.aux`
	echo ${APP} > ${APP_PROC}
	if [ ! -s ${APP_PROC} ]
	then
		gen_log "--- No se pudo generar el puntero de grupo de aplicaciones en proceso"
		exit 10
	fi
	rm -f ${APP_PROC}.bkp
	exit 0
else
	if [ -f ${APP_LIST}.aux ]
	then
		gen_log "Fin de lista de grupos de aplicaciones"
	fi
	gen_log "Fin del backup de ${APP} correspondiente al ${DD}/${MM}/${YYYY}"
	mt -f ${TAPE} rewoffl
	exit 1
fi



