set -x
##############################################################################
#
# Actualiza la lista auxiliar de DF del TS en proceso. El nuevo contenido de
# esta, sera el ultimo DF indicado en ${LOG_AUX} , mas todos los que siguen
# despues de este en la lista auxiliar de DF del TS en proceso.
# Luego expulsa la cinta recien procesada, y genera condicion para cambio
# manual o automatico de la misma.
#
#
# exit status:
#    0  - OK. Cambio de cinta automatico.
#    1  - OK. Cambio de cinta manual.
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  09/12/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

BKP_LOG=${3}
DF_LIST=${6}
LOG_AUX=${7}
TAPE=${8}
JUKEBOX=${10}

if [ ! -s ${LOG_AUX} ]
then
	gen_log "--- Log auxiliar ${LOG_AUX} inexistente"
	gen_log "--- Se aborta el backup"
	exit 10
fi

if [ ! -s ${DF_LIST}.aux ]
then
	gen_log "--- Lista auxiliar de DF inexistente"
	gen_log "--- Se aborta el backup"
	exit 10
fi

> ${LOG_AUX}.tmp
if [ $? != 0 ]
then
	gen_log "--- No se pudo inicializar la lista ${LOG_AUX}.tmp"
	exit 10
fi

> ${LOG_AUX}.tmp.2
if [ $? != 0 ]
then
	gen_log "--- No se pudo inicializar la lista ${LOG_AUX}.tmp.2"
	exit 10
fi

cat ${LOG_AUX} |awk '{print $2}' > ${LOG_AUX}.tmp
if [ ! -s ${LOG_AUX}.tmp ]
then
	gen_log "--- No se pudo generar la lista ${LOG_AUX}.tmp"
	exit 10
fi

tail -1 ${LOG_AUX}.tmp > ${LOG_AUX}.tmp.2
if [ ! -s ${LOG_AUX}.tmp.2 ]
then
	gen_log "--- No se pudo generar la lista ${LOG_AUX}.tmp.2"
	exit 10
fi

diff ${DF_LIST}.aux ${LOG_AUX}.tmp| tail +2 | awk '{print $2}' >> ${LOG_AUX}.tmp.2

cp -pf ${DF_LIST}.aux ${DF_LIST}.bkp

diff ${DF_LIST}.aux ${DF_LIST}.bkp
if [ $? != 0 ]
then
	gen_log "--- No se pudo hacer copia de la lista auxiliar de DF"
	exit 10
fi

rm -f ${DF_LIST}.aux
if [ -f ${DF_LIST}.aux ]
then
	gen_log "--- No se pudo borrar la lista auxiliar de DF"
	exit 10
fi

mv -f ${LOG_AUX}.tmp.2 ${DF_LIST}.aux
if [ ! -s ${DF_LIST}.aux ]
then
	gen_log "--- No se pudo generar la lista auxiliar de DF"
	exit 10
fi

rm -f ${LOG_AUX}.tmp ${DF_LIST}.bkp

mt -f ${TAPE} rewoffl

if [ ${JUKEBOX} = YES ]
then
	gen_log "Fin de cinta. La unidad carga la siguiente"
	exit 0
else
	gen_log "Fin de cinta. Un Operador debe cargar la siguiente"
	exit 1
fi



