set -x
##############################################################################
#
# Controla que haya una cinta en la unidad correspondiente.
#
#
# exit status:
#    0  - OK
#    1  - Error. No hay cinta en la unidad.
#
#
# Cesar Lopez  -  29/11/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

BKP_LOG=${3}
TAPE=${8}

mt -f ${TAPE} rewind
if [ $? = 0 ]
then
	exit 0
else
	gen_log "--- No hay cinta colocada en la unidad"
	exit 1
fi



