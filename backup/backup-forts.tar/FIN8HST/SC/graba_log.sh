set -x
##############################################################################
#
# Graba a cinta el grupo de LOGS en proceso, y actualiza el contador de
# bloques de cinta.
#
#
# exit status:
#    0  - OK. Fin de lista de LOGS del grupo en proceso.
#    1  - OK. Fin de cinta.
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  12/12/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

APP=${1}
BKP_LOG=${3}
LOG_AUX=${7}
TAPE=${8}
BLK_COUNT=${13}
LOG_LIST=${16}

CTL=/tmp/control.${APP}
TAR_ERR=/tmp/tar_err.${APP}

typeset -i COUNT

> ${CTL}
if [ $? != 0 ]
then
	gen_log "--- No se pudo generar el control de grabacion"
	exit 10
fi

> ${TAR_ERR}
if [ $? != 0 ]
then
	gen_log "--- No se pudo inicializar el log ${TAR_ERR}"
	exit 10
fi

> ${LOG_AUX}
if [ $? != 0 ]
then
	gen_log "--- No se pudo inicializar el log ${LOG_AUX}"
	exit 10
fi

if [ ! -s ${LOG_LIST}.aux ]
then
	gen_log "--- Lista auxiliar de LOGS a grabar inexistente"
	gen_log "--- Se aborta el backup"
	exit 10
fi

if [ ! -s ${BLK_COUNT} ]
then
	gen_log "--- Contador de bloques inexistente"
	gen_log "--- Se aborta el backup"
	exit 10
fi

COUNT=`cat ${BLK_COUNT}`

let "COUNT = COUNT + 1"

cp -pf ${BLK_COUNT} ${BLK_COUNT}.bkp

diff ${BLK_COUNT} ${BLK_COUNT}.bkp
if [ $? != 0 ]
then
	gen_log "--- No se pudo hacer copia del contador de bloques"
	exit 10
fi

rm -f ${BLK_COUNT}
if [ -f ${BLK_COUNT} ]
then
	gen_log "--- No se pudo borrar el contador de bloques"
	exit 10
fi

echo $COUNT > ${BLK_COUNT}
if [ ! -s ${BLK_COUNT} ]
then
	gen_log "--- No se pudo actualizar el contador de bloques"
	exit 10
fi

rm -f ${BLK_COUNT}.bkp

echo "-----------------------------------------------------------------------------" >> ${BKP_LOG}
gen_log "Grabando bloque de cinta numero ${COUNT}"

LIST=`cat ${LOG_LIST}.aux`

cd /

tar -cvf ${TAPE}.1 ${LIST} ${CTL} 2>${TAR_ERR}|tee -a ${BKP_LOG}|tee ${LOG_AUX}

LAST_LIN=`tail -1 ${LOG_AUX} |awk '{print $2}'`
STATUS=$?

if [ ${LAST_LIN} != ${CTL} ] || [ ${STATUS} -ne 0 ]
then
	if [ ! -s ${TAR_ERR} ]
	then
		gen_log "--- Ocurrio un error de grabacion, pero no se pudo generar el log ${TAR_ERR}"
		gen_log "--- Se aborta el backup"
		exit 10
	fi
	grep 0511-171 ${TAR_ERR}
	if [ $? = 0 ]
	then
		exit 1
	else
		gen_log "--- Error de grabacion. Ver archivo ${TAR_ERR}"
		gen_log "--- Se aborta el backup"
		exit 10
	fi
else
	rm -f ${CTL} ${TAR_ERR}
	exit 0
fi



