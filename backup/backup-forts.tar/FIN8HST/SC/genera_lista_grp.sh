set -x
##############################################################################
#
# Inhabilita la ejecucion del job ciclico que comprime los LOGS, y comprime
# los LOGS pendientes desde su ultima ejecucion. Para el primer LOG de la
# lista (ultimo generado por la base), realiza un control para asegurar que
# el 'archiver' de la base de datos haya finalizado la copia desde el
# directorio donde los genera, al directorio ${LOG_PATH}
# Genera las listas completa y auxiliar, de grupos de LOGS a procesar en el
# backup.
#
#
# exit status:
#    0  - OK
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  13/02/2003
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

BKP_LOG=${3}
GRP_LIST=${14}
DB_LOG_LIST=${17}
LOG_QTY=${18}
LOG_PATH_LIST=${23}

for LOG_PATH in `cat ${LOG_PATH_LIST} |grep -v ^#`
do
	gen_log "Procesando LOGS en ${LOG_PATH}"
	typeset -i GRP
	typeset -i DIV
	typeset -i TOTAL
	typeset -i AUX
	AUX=0
	FIRST=0
	cd ${LOG_PATH}
	if [ $? != 0 ]
	then
		gen_log "--- No se pudo acceder a ${LOG_PATH}"
		exit 10
	fi
	if [ -s arch??????????.log ]
	then
		gen_log "Comprimiendo LOGS pendientes"
		for LOG in `ls -1t |grep "\.log" |grep -v "\.Z"`
		do
			if [ ${FIRST} = 0 ]
			then
				while true
				do
					cp -pf ${LOG} ${LOG}.aux
					sleep 120
					SUM1=`sum ${LOG} |cut -f1 -d" "`
					SUM2=`sum ${LOG}.aux |cut -f1 -d" "`
					if [ ${SUM1} = ${SUM2} ]
					then
						gen_log "Comprimiendo ${LOG}"
						compress -f ${LOG}
						if [ $? != 0 ]
						then
							gen_log "--- Error comprimiendo LOG ${LOG}"
							exit 10
						fi
						compress -f ${LOG}.aux
						if [ $? != 0 ]
						then
							gen_log "--- Error comprimiendo archivo de control ${LOG}.aux"
							exit 10
						fi
						SUM1=`sum ${LOG}.Z |cut -f1 -d" "`
						SUM2=`sum ${LOG}.aux.Z |cut -f1 -d" "`
						if [ ${SUM1} = ${SUM2} ]
						then
							rm -f ${LOG}.aux.Z
							FIRST=1
							break
						else
							gen_log "--- Se comprimio el LOG ${LOG} estando incompleto"
							exit 10
						fi
					fi
				done
			else
				gen_log "Comprimiendo ${LOG}"
				compress -f ${LOG}
				if [ $? != 0 ]
				then
					gen_log "--- Error comprimiendo LOG ${LOG}"
					exit 10
				fi
			fi
		done
		gen_log "Compresion de LOGS pendientes OK"
	else
		gen_log "No hay LOGS pendientes para comprimir"
	fi
done

gen_log "Generando lista de LOGS"

rm -f ${DB_LOG_LIST}
if [ -f ${DB_LOG_LIST} ]
then
	gen_log "--- No se pudo borrar la lista de LOGS"
	exit 10
fi

rm -f ${DB_LOG_LIST}.aux
if [ -f ${DB_LOG_LIST}.aux ]
then
	gen_log "--- No se pudo borrar la lista auxiliar de LOGS"
	exit 10
fi

cd /

for LOG_PATH in `cat ${LOG_PATH_LIST} |grep -v ^#`
do
	ls ${LOG_PATH} | grep "^arch" | grep "\.log\.Z$" > ${DB_LOG_LIST}.aux
	sed s"(^(.${LOG_PATH}/(" ${DB_LOG_LIST}.aux >> ${DB_LOG_LIST}
done

if [ ! -s ${DB_LOG_LIST} ]
then
	gen_log "--- No se pudo generar la lista de LOGS"
	exit 10
fi

gen_log "Lista de LOGS generada OK"

DIV=`wc -l ${DB_LOG_LIST} |awk '{print $1}'`

let "TOTAL = DIV / LOG_QTY"
let "AUX = TOTAL * LOG_QTY"
if [ ${DIV} -ne ${AUX} ]
then
	let "TOTAL = TOTAL + 1"
fi

> ${GRP_LIST}
if [ $? != 0 ]
then
	gen_log "--- No se pudo inicializar la lista de grupos de LOGS"
	exit 10
fi

gen_log "Generando lista de grupos de LOGS"

GRP=1
while [ ${GRP} -le ${TOTAL} ]
do
	echo ${GRP} >> ${GRP_LIST}
	let "GRP = GRP + 1"
done

if [ ! -s ${GRP_LIST} ]
then
	gen_log "--- No se pudo generar la lista de grupos de LOGS"
	exit 10
fi

cp -pf ${GRP_LIST} ${GRP_LIST}.aux

diff ${GRP_LIST} ${GRP_LIST}.aux
if [ $? != 0 ]
then
	gen_log "--- No se pudo generar la lista auxiliar de grupos de LOGS"
	exit 10
fi

rm -f ${DB_LOG_LIST}.aux

gen_log "Lista de grupos de LOGS generada OK"

exit 0



