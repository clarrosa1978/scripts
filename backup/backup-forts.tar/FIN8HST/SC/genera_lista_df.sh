set -x
##############################################################################
#
# Si el nombre del TS en proceso es "@LISTA__CTL__LOGS", genera en ${DF_LIST}
# la lista de control files y redologs activos, para grabarlos a cinta con
# el mismo criterio que si fueran DF.
# Si el nombre del TS en proceso es diferente a "@LISTA__CTL__LOGS", marca el
# mismo en modo 'BEGIN BACKUP', y genera la lista de DF que le corresponden.
#
#
# exit status:
#    0  - OK
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  27/11/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

BKP_LOG=${3}
TS_PROC=${5}
DF_LIST=${6}

if [ ! -s ${TS_PROC} ]
then
	gen_log "--- Puntero de TS en proceso inexistente"
	gen_log "--- Se aborta el backup"
	exit 10
fi

> ${DF_LIST}
if [ $? != 0 ]
then
	gen_log "--- No se pudo inicializar la lista de DF"
	exit 10
fi

gen_log "Marcando en modo 'BEGIN BACKUP', y generando lista de DF"

for i in `cat ${TS_PROC}`
do
	ORA_USR=`echo ${i} |cut -f1 -d:`
	INSTANCE=`echo ${i} |cut -f2 -d:`
	TS=`echo ${i} |cut -f3 -d:`
	if [ ${TS} = "@LISTA__CTL__LOGS" ]
	then
		gen_log "Generando lista de control files y redologs activos"
		gen_log " de la instancia ${INSTANCE}"
		if [ ! -s ~${ORA_USR}/backup/onlineMgr.sh ]
		then
			gen_log "--- No existe el script ~${ORA_USR}/backup/onlineMgr.sh"
			exit 10
		fi
		su - ${ORA_USR} -c "export ORACLE_SID=${INSTANCE}; ~${ORA_USR}/backup/onlineMgr.sh"
		STATUS=$?
		if [ ${STATUS} != 0 ]
		then
			gen_log "--- Error en ejecucion del onlineMgr.sh  -  status: ${STATUS}"
			exit 10
		fi
		if [ ! -s ~${ORA_USR}/backup/listas/lOnline4bkp.asc ]
		then
			gen_log "--- No se pudo generar la lista de control files y redologs activos"
			exit 10
		fi
		cat ~${ORA_USR}/backup/listas/lOnline4bkp.asc >> ${DF_LIST}
	else
		gen_log "Instancia: ${INSTANCE}  -  TS: ${TS}"
		if [ ! -s ~${ORA_USR}/backup/fileMgr.sh ]
		then
			gen_log "--- No existe el script ~${ORA_USR}/backup/fileMgr.sh"
			exit 10
		fi
		su - ${ORA_USR} -c "export ORACLE_SID=${INSTANCE}; ~${ORA_USR}/backup/fileMgr.sh BEGIN ${TS}"
		STATUS=$?
		if [ ${STATUS} != 0 ]
		then
			gen_log "--- Error en ejecucion del fileMgr.sh  -  status: ${STATUS}"
			exit 10
		fi
		if [ ! -s ~${ORA_USR}/backup/listas/lFiles4bkp.asc ]
		then
			gen_log "--- No se pudo generar la lista de DF"
			exit 10
		fi
		cat ~${ORA_USR}/backup/listas/lFiles4bkp.asc >> ${DF_LIST}
	fi
done

cp -pf ${DF_LIST} ${DF_LIST}.aux
diff ${DF_LIST} ${DF_LIST}.aux
if [ $? != 0 ]
then
	gen_log "--- No se pudo generar la lista auxiliar de DF"
	exit 10
fi

gen_log "Marca 'BEGIN BACKUP', y lista generada OK"

exit 0



