#!/usr/bin/ksh
set -x
##############################################################################
#
# Fuerza al estado "OK" todos los jobs ciclicos que quedaron en espera de
# una nueva ejecucion, para que sean borrados por el "New Day Procedure"
#
#
# Cesar Lopez  -  15/04/2003
#
##############################################################################

ODATE=${1}
NODEGRP=${2}
APPLIC=${3}

SQL << eof
create procedure forceok @memname char(30), @odate char(8), @nodegrp char(50), @applic char(20) as
	update CMR_AJF
	set STATE = '8', STATUS = 'Y'
	where MEMNAME = @memname
	and ODATE = @odate
	and NODEGRP = @nodegrp
	and APPLIC = @applic
go
eof

SQL << eof
exec forceok "act_lista_aux_df.sh", "${ODATE}", "${NODEGRP}", "${APPLIC}"
go
exec forceok "act_lista_aux_file.sh", "${ODATE}", "${NODEGRP}", "${APPLIC}"
go
exec forceok "act_lista_aux_log.sh", "${ODATE}", "${NODEGRP}", "${APPLIC}"
go
exec forceok "chk_seq.sh", "${ODATE}", "${NODEGRP}", "${APPLIC}"
go
exec forceok "chk_tape1.sh", "${ODATE}", "${NODEGRP}", "${APPLIC}"
go
exec forceok "desmarca_ts.sh", "${ODATE}", "${NODEGRP}", "${APPLIC}"
go
exec forceok "genera_lista_df.sh", "${ODATE}", "${NODEGRP}", "${APPLIC}"
go
exec forceok "genera_lista_file.sh", "${ODATE}", "${NODEGRP}", "${APPLIC}"
go
exec forceok "genera_lista_log.sh", "${ODATE}", "${NODEGRP}", "${APPLIC}"
go
exec forceok "graba_df.sh", "${ODATE}", "${NODEGRP}", "${APPLIC}"
go
exec forceok "graba_file.sh", "${ODATE}", "${NODEGRP}", "${APPLIC}"
go
exec forceok "graba_log.sh", "${ODATE}", "${NODEGRP}", "${APPLIC}"
go
exec forceok "next_tape.sh", "${ODATE}", "${NODEGRP}", "${APPLIC}"
go
exec forceok "siguiente_app.sh", "${ODATE}", "${NODEGRP}", "${APPLIC}"
go
exec forceok "siguiente_grp.sh", "${ODATE}", "${NODEGRP}", "${APPLIC}"
go
exec forceok "siguiente_ts.sh", "${ODATE}", "${NODEGRP}", "${APPLIC}"
go
drop procedure forceok
go
eof

exit 0



