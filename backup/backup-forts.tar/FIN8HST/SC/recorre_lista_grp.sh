set -x
##############################################################################
#
# Genera el puntero de grupo de LOGS en proceso, a partir de la lista auxiliar
# de grupos de LOGS.
#
#
# exit status:
#    0  - OK
#    1  - OK. (no hay mas grupos de LOGS para procesar)
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  12/12/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

APP=${1}
BKP_LOG=${3}
GRP_LIST=${14}
GRP_PROC=${15}

if [ ! -f ${GRP_LIST}.aux ]
then
	gen_log "--- Lista auxiliar de grupos inexistente"
	gen_log "--- Se aborta el backup"
	exit 10
fi

LINES=`wc -l ${GRP_LIST}.aux | awk '{print $1}'`
if [ ${LINES} -ge 1 ]
then
	if [ -f ${GRP_PROC} ]
	then
		cp -pf ${GRP_PROC} ${GRP_PROC}.bkp
		diff ${GRP_PROC} ${GRP_PROC}.bkp
		if [ $? != 0 ]
		then
			gen_log "--- No se pudo hacer copia del puntero de grupo de LOGS en proceso"
			exit 10
		fi
		rm -f ${GRP_PROC}
		if [ -f ${GRP_PROC} ]
		then
			gen_log "--- No se pudo borrar el puntero de grupo en proceso"
			exit 10
		fi
	fi
	GRP=`head -1 ${GRP_LIST}.aux`
	echo ${GRP} > ${GRP_PROC}
	if [ ! -s ${GRP_PROC} ]
	then
		gen_log "--- No se pudo generar el puntero de grupo en proceso"
		exit 10
	fi
	rm -f ${GRP_PROC}.bkp
	exit 0
else
	gen_log "Fin de lista de grupos de LOGS"
	gen_log "Fin del backup de DF y LOGS de ${APP}"
	exit 1
fi



