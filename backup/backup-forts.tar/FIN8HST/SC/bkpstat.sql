set feedback off
set pagesize 0

spool &1

select count (*) from v$backup where STATUS != 'NOT ACTIVE';

spool off

quit



