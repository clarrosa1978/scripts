set -x
##############################################################################
#
# Actualiza la lista auxiliar de grupos de LOGS para que apunte al siguiente
# grupo a procesar.
#
#
# exit status:
#    0  - OK
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  12/12/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

BKP_LOG=${3}
GRP_LIST=${14}

if [ ! -s ${GRP_LIST}.aux ]
then
	gen_log "--- No existe la lista auxiliar de grupos de LOGS"
	gen_log "--- Se aborta el backup"
	exit 10
fi

rm -f ${GRP_LIST}.tmp
if [ -f ${GRP_LIST}.tmp ]
then
	gen_log "--- No se pudo borrar la lista auxiliar temporal de grupos de LOGS"
	exit 10
fi

tail +2 ${GRP_LIST}.aux > ${GRP_LIST}.tmp
if [ ! -f ${GRP_LIST}.tmp ]
then
	gen_log "--- No se pudo generar la lista auxiliar temporal de grupos de LOGS"
	exit 10
fi

cp -pf ${GRP_LIST}.aux ${GRP_LIST}.bkp

diff ${GRP_LIST}.aux ${GRP_LIST}.bkp
if [ $? != 0 ]
then
	gen_log "--- No se pudo hacer copia de la lista auxiliar de grupos de LOGS"
	exit 10
fi

rm -f ${GRP_LIST}.aux
if [ -f ${GRP_LIST}.aux ]
then
	gen_log "--- No se pudo borrar la lista auxiliar de grupos de LOGS"
	exit 10
fi

mv -f ${GRP_LIST}.tmp ${GRP_LIST}.aux

if [ ! -f ${GRP_LIST}.aux ]
then
	gen_log "--- No se pudo generar la lista auxiliar de grupos de LOGS"
	exit 10
fi

rm -f ${GRP_LIST}.bkp

exit 0



