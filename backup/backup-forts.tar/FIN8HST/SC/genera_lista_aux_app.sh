set -x
##############################################################################
#
# Genera la lista auxiliar de grupos de aplicaciones.
#
#
# exit status:
#    0  - OK
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  14/02/2003
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

BKP_LOG=${3}
APP_LIST=${20}

if [ -s ${APP_LIST} ]
then
	cp -pf ${APP_LIST} ${APP_LIST}.aux
	diff ${APP_LIST} ${APP_LIST}.aux
	if [ $? != 0 ]
	then
		gen_log "--- No se pudo generar la lista auxiliar de grupos de aplicaciones"
		exit 10
	fi
else
	> ${APP_LIST}.aux
	if [ $? != 0 ]
	then
		gen_log "--- No se pudo inicializar la lista auxiliar de grupos de aplicaciones"
		exit 10
	fi
fi

exit 0



