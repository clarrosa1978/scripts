set -x
##############################################################################
#
# Genera las listas completa y auxiliar de archivos correspondientes al grupo
# de aplicaciones en proceso.
#
#
# exit status:
#    0  - OK
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  26/12/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

BKP_LOG=${3}
APP_PROC=${21}
FILE_LIST=${22}

if [ ! -s ${APP_PROC} ]
then
	gen_log "--- Puntero de grupo de aplicaciones en proceso inexistente"
	gen_log "--- Se aborta el backup"
	exit 10
fi

APP_AUX=`cat ${APP_PROC}`
APP_AUX1=`cat ${APP_AUX}`

gen_log "Generando lista de archivos del grupo de aplicaciones ${APP_AUX}"

rm -f ${FILE_LIST}
if [ -f ${FILE_LIST} ]
then
	gen_log "--- No se pudo borrar la lista de archivos"
	exit 10
fi

cd /

for i in ${APP_AUX1}
do
	for j in b c f l p s
	do
		find ${i} -type ${j} -name ".*" >> ${FILE_LIST}
		find ${i} -type ${j} -name "*" >> ${FILE_LIST}
	done
done

if [ ! -s ${FILE_LIST} ]
then
	gen_log "--- No se pudo generar la lista de archivos"
	exit 10
fi

cp -pf ${FILE_LIST} ${FILE_LIST}.aux

diff ${FILE_LIST} ${FILE_LIST}.aux
if [ $? != 0 ]
then
	gen_log "--- No se pudo generar la lista auxiliar de archivos"
	exit 10
fi

gen_log "Lista de archivos generada OK"

exit 0



