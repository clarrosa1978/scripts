set -x
##############################################################################
#
# Actualiza la lista auxiliar de grupos de aplicaciones para que apunte al
# siguiente grupo a procesar.
#
#
# exit status:
#    0  - OK
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  20/12/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

BKP_LOG=${3}
APP_LIST=${20}

if [ ! -s ${APP_LIST}.aux ]
then
	gen_log "--- No existe la lista auxiliar de grupos de aplicaciones"
	gen_log "--- Se aborta el backup"
	exit 10
fi

rm -f ${APP_LIST}.tmp
if [ -f ${APP_LIST}.tmp ]
then
	gen_log "--- No se pudo borrar la lista auxiliar temporal de grupos de aplicaciones"
	exit 10
fi

tail +2 ${APP_LIST}.aux > ${APP_LIST}.tmp
if [ ! -f ${APP_LIST}.tmp ]
then
	gen_log "--- No se pudo generar la lista auxiliar temporal de grupos de aplicaciones"
	exit 10
fi

cp -pf ${APP_LIST}.aux ${APP_LIST}.bkp

diff ${APP_LIST}.aux ${APP_LIST}.bkp
if [ $? != 0 ]
then
	gen_log "--- No se pudo hacer copia de la lista auxiliar de grupos de aplicaciones"
	exit 10
fi

rm -f ${APP_LIST}.aux
if [ -f ${APP_LIST}.aux ]
then
	gen_log "--- No se pudo borrar la lista auxiliar de grupos de aplicaciones"
	exit 10
fi

mv -f ${APP_LIST}.tmp ${APP_LIST}.aux

if [ ! -f ${APP_LIST}.aux ]
then
	gen_log "--- No se pudo generar la lista auxiliar de grupos de aplicaciones"
	exit 10
fi

rm -f ${APP_LIST}.bkp

exit 0



