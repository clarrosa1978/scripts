set -x
exit 0

##############################################################################
#
# Borra los LOGS procesados en el backup en curso
#
#
# exit status:
#    0  - OK
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  16/03/2004
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

BKP_LOG=${3}
DB_LOG_LIST=${17}

if [ ! -s ${DB_LOG_LIST} ]
then
	gen_log "--- No existe la lista ${DB_LOG_LIST}"
	exit 10
fi

cd /

for LOG in `cat ${DB_LOG_LIST}`
do
	rm -f ${LOG}
done

exit 0



