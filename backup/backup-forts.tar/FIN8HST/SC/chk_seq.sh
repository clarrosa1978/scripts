set -x
##############################################################################
#
# Verifica si la secuencia correspondiente al dia coincide con la de la cinta
# colocada en la unidad, e inicializa el contador de bloques de cinta.
#
#
# exit status:
#    0  - OK. Secuencia correcta.
#    1  - Error. Secuencia incorrecta.
#    2  - Error. Cinta protegida.
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  29/11/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

APP=${1}
BKP_LOG=${3}
TAPE=${8}
BS=${9}
SEQ_DIR=${11}
TAPE_PROC=${12}
BLK_COUNT=${13}

CTL=/tmp/control.${APP}
TAR_ERR=/tmp/tar_err.${APP}

set -A TABLE A B C D E F G H I J K L M N O P Q R S T U V W X Y Z

if [ ! -s ${TAPE_PROC} ]
then
	gen_log "--- No existe puntero de cinta en proceso"
	gen_log "--- Se aborta el backup"
	exit 10
fi

POS=`cat ${TAPE_PROC}`
if [ ${POS} -gt 25 ]
then
	gen_log "--- Demasiadas cintas para una secuencia !!"
	gen_log "--- Se aborta el backup"
	exit 10
fi

NEXT_SEQ=`ls -t ${SEQ_DIR} |tail -1`
if [ "x${NEXT_SEQ}" = "x" ]
then
	gen_log "--- No se pudo obtener la secuencia a utilizar"
	exit 10
fi

NEXT_TAPE=${TABLE[POS]}

LABEL=SECUENCIA_${NEXT_SEQ}_${NEXT_TAPE}_${APP}

ACT_TAPE=`dd if=${TAPE} ibs=${BS}k count=1 conv=noerror 2>/dev/null | awk ' { print $1 } ' |grep SECUENCIA_`

if [ x${LABEL} != x${ACT_TAPE} ]
then
	gen_log "--- Secuencia incorrecta"
	gen_log "--- Cinta actual: ${ACT_TAPE}"
	gen_log "--- Corresponde : ${LABEL}"
	gen_log "--- Un operador debe cambiar la cinta"
	gen_log "--- ---------------------------------"
	exit 1
fi

> ${LABEL}
if [ $? != 0 ]
then
	gen_log "--- No se pudo inicializar la secuencia actual"
	exit 10
fi

> ${CTL}
if [ $? != 0 ]
then
	gen_log "--- No se pudo inicializar el control de grabacion"
	exit 10
fi

tar -cvf ${TAPE}.1 ${LABEL} ${CTL} 2>${TAR_ERR}| tee -a ${BKP_LOG}

LAST_LIN=`tail -1 ${BKP_LOG} |awk '{print $2}'`
STATUS=$?

if [ ${LAST_LIN} != ${CTL} ] || [ ${STATUS} -ne 0 ]
then
	if [ ! -s ${TAR_ERR} ]
	then
		gen_log "--- Ocurrio un error grabando la etiqueta de secuencia, pero"
		gen_log "--- no se pudo generar el log ${TAR_ERR}"
	else
		grep write-protected ${TAR_ERR}
		if [ $? = 0 ]
		then
			gen_log "--- Error por cinta protegida"
			gen_log "--- -------------------------"
			exit 2
		else
			gen_log "--- Error grabando etiqueta de secuencia"
			gen_log "--- Ver archivo ${TAR_ERR}"
		fi
	fi
	gen_log "--- Coloque otra cinta con la secuencia ${LABEL} y"
	gen_log "--- ejecute nuevamente este job"
	exit 10
fi

echo "0" > ${BLK_COUNT}
COUNT=`cat ${BLK_COUNT}`
if [ x0 != x${COUNT} ]
then
	gen_log "--- No se pudo inicializar el contador de bloques"
	exit 10
fi

echo "==============================================================================" >> ${BKP_LOG}
gen_log "Procesando cinta ${LABEL}"
echo "==============================================================================" >> ${BKP_LOG}

rm -f ${CTL} ${TAR_ERR} ${LABEL}

exit 0



