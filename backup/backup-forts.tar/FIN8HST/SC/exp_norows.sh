set -x
##############################################################################
#
# Genera export sin filas para cada instancia, dependiendo del valor de la
# variable ${BKP_TYPE}
# Este export se deberia grabar a cinta junto a los archivos "planos" definidos
# en alguna de las listas indicadas por el parametro 20 (variable  ${APP_LIST} )
#
#
# exit status:
#    0  - OK
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  29/04/2003
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

APP=${1}
BKP_LOG=${3}
ORA_USR_LIST=${19}

for i in `cat ${ORA_USR_LIST} |grep -v ^#`
do
	BKP_TYPE=`echo ${i} |cut -f3 -d:`
	if [ ${BKP_TYPE} = ALL ]
	then
		continue
	fi
	ORA_USR=`echo ${i} |cut -f1 -d:`
	INSTANCE=`echo ${i} |cut -f2 -d:`
	DMP=`echo ${i} |cut -f4 -d:`
	BUFFER=`echo ${i} |cut -f5 -d:`
	DMP_OUT=${DMP}.dmp.Z
	EXP_LOG=${DMP}.log
	FIFO=/tmp/fifo_${INSTANCE}.dmp
	gen_log "Generando export sin filas para la instancia ${INSTANCE}"
	> ${DMP_OUT}
	if [ $? != 0 ]
	then
		gen_log "--- No se pudo inicializar el archivo del export"
		exit 10
	fi
	chown ${ORA_USR} ${DMP_OUT}
	> ${EXP_LOG}
	if [ $? != 0 ]
	then
		gen_log "--- No se pudo inicializar el log del export"
		exit 10
	fi
	chown ${ORA_USR} ${EXP_LOG}
	rm -f ${FIFO}
	if [ -f ${FIFO} ]
	then
		gen_log "--- No se pudo borrar el fifo ${FIFO}"
		exit 10
	fi
	mknod ${FIFO} p
	chmod 644 ${FIFO}
	chown ${ORA_USR} ${FIFO}
	nohup cat ${FIFO} | compress > ${DMP_OUT} &
	su - ${ORA_USR} -c "export ORACLE_SID=${INSTANCE}; exp / buffer=${BUFFER} rows=n full=y file=${FIFO} compress=n log=${EXP_LOG}"
	STATUS=$?
	OK=`tail -1 ${EXP_LOG} | grep "Export terminated successfully without warnings"`
	OK_EXP=`grep "EXP-" ${EXP_LOG}`
	OK_ORA=`grep "ORA-" ${EXP_LOG}`
	if [ "x${OK}" = "x" ] || [ ${STATUS} != 0 ] || [ x${OK_EXP} != "x" ] || [ x${OK_ORA} != "x" ]
	then
		gen_log "--- Error generando export sin filas"
		exit 10
	fi
	gen_log "Export generado OK"
done
