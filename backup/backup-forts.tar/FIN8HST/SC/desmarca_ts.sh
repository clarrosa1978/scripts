set -x
##############################################################################
#
# Marca en modo 'END BACKUP' el TS en proceso, excepto cuando el nombre del
# mismo es "@LISTA__CTL__LOGS" (ver los procesos  genera_lista_ts.sh  y
# genera_lista_df.sh)
#
#
# exit status:
#    0  - OK
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  29/11/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

BKP_LOG=${3}
TS_PROC=${5}

if [ ! -s ${TS_PROC} ]
then
	gen_log "--- Puntero de TS en proceso inexistente"
	gen_log "--- Se aborta el backup"
	exit 10
fi

gen_log "Marcando en modo 'END BACKUP'"

for i in `cat ${TS_PROC}`
do
	ORA_USR=`echo ${i} |cut -f1 -d:`
	INSTANCE=`echo ${i} |cut -f2 -d:`
	TS=`echo ${i} |cut -f3 -d:`
	if [ ${TS} != "@LISTA__CTL__LOGS" ]
	then
		gen_log "Instancia: ${INSTANCE}  -  TS: ${TS}"
		if [ ! -s ~${ORA_USR}/backup/fileMgr.sh ]
		then
			gen_log "--- No existe el script ~${ORA_USR}/backup/fileMgr.sh"
			exit 10
		fi
		su - ${ORA_USR} -c "export ORACLE_SID=${INSTANCE}; ~${ORA_USR}/backup/fileMgr.sh END ${TS}"
		if [ $? != 0 ]
		then
			gen_log "--- Error en ejecucion del fileMgr.sh"
			exit 10
		fi
	fi
done

gen_log "Marca 'END BACKUP' OK"

exit 0



