set -x
##############################################################################
#
# Comienzo del backup. Inicializacion de logs, y puntero de cinta en proceso.
#
#
# exit status:
#    0  - OK
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  03/12/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

APP=${1}
DATE=${2}
BKP_LOG=${3}
TS_LIST=${4}
TS_PROC=${5}
DF_LIST=${6}
LOG_AUX=${7}
TAPE_PROC=${12}
BLK_COUNT=${13}
GRP_LIST=${14}
GRP_PROC=${15}
LOG_LIST=${16}
DB_LOG_LIST=${17}
APP_PROC=${21}
FILE_LIST=${22}

YYYY=`echo ${DATE} | cut -c 1-4`
MM=`echo ${DATE} | cut -c 5-6`
DD=`echo ${DATE} | cut -c 7-8`

> ${BKP_LOG}
if [ $? != 0 ]
then
	echo "No se pudo inicializar el log del backup ${BKP_LOG}"
	exit 10
fi

gen_log "${DD}/${MM}/${YYYY} - Comienzo del backup de ${APP} "

echo "0" > ${TAPE_PROC}

POS=`cat ${TAPE_PROC}`
if [ x${POS} != "x0" ]
then
	gen_log "--- No se pudo generar el puntero de cinta en proceso"
	exit 10
fi

rm -f ${TS_LIST} ${TS_LIST}.aux
rm -f ${TS_PROC}
rm -f ${DF_LIST} ${DF_LIST}.aux
rm -f ${LOG_AUX} ${LOG_AUX}.aux
rm -f ${BLK_COUNT}
rm -f ${GRP_LIST} ${GRP_LIST}.aux
rm -f ${GRP_PROC}
rm -f ${LOG_LIST} ${LOG_LIST}.aux
rm -f ${DB_LOG_LIST}
rm -f ${APP_PROC}
rm -f ${FILE_LIST} ${FILE_LIST}.aux

exit 0



