set -x
##############################################################################
#
# Actualiza el puntero de cinta en proceso.
#
#
# exit status:
#    0  - OK
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  05/12/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

BKP_LOG=${3}
TAPE_PROC=${12}

typeset -i POS

if [ ! -s ${TAPE_PROC} ]
then
	gen_log "--- No existe puntero de cinta en proceso"
	gen_log "--- Se aborta el backup"
	exit 10
fi

POS=`cat ${TAPE_PROC}`
let "POS = POS + 1"
if [ ${POS} -gt 25 ]
then
	gen_log "--- Demasiadas cintas para una secuencia !!"
	gen_log "--- Se aborta el backup"
	exit 10
fi

cp -pf ${TAPE_PROC} ${TAPE_PROC}.bkp

diff ${TAPE_PROC} ${TAPE_PROC}.bkp
if [ $? != 0 ]
then
	gen_log "--- No se pudo hacer copia del puntero de cinta"
	exit 10
fi

echo ${POS} > ${TAPE_PROC}

POS_AUX=`cat ${TAPE_PROC}`
if [ x${POS} != x${POS_AUX} ]
then
	gen_log "--- No se pudo actualizar el puntero de cinta en proceso"
	exit 10
fi

rm -f ${TAPE_PROC}.bkp

exit 0



