set -x
##############################################################################
#
# Verifica que no haya TS en modo 'BEGIN BACKUP'
#
#
# exit status:
#    0  - OK
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  18/02/2003
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

APP=${1}
BKP_LOG=${3}
ORA_USR_LIST=${19}

SC=/`basename $0`
SCR_PATH=`echo $0 |sed s"($SC(("`

if [ ! -s ${ORA_USR_LIST} ]
then
	gen_log "--- No existe la lista usuarios/instancias de bases de datos"
	exit 10
fi

for i in `cat ${ORA_USR_LIST} |grep -v ^#`
do
	ORA_USR=`echo ${i} |cut -f1 -d:`
	INSTANCE=`echo ${i} |cut -f2 -d:`
	BKPSTAT_TMP=/tmp/bkpstat.${APP}.${ORA_USR}
	> ${BKPSTAT_TMP}
	if [ $? != 0 ]
	then
		gen_log "--- No se pudo inicializar el archivo de control ${BKPSTAT_TMP}"
		exit 10
	fi
	chown ${ORA_USR} ${BKPSTAT_TMP}
	su - ${ORA_USR} -c "export ORACLE_SID=${INSTANCE}; sqlplus / @${SCR_PATH}/bkpstat.sql ${BKPSTAT_TMP}"
	if [ ! -s ${BKPSTAT_TMP} ]
	then
		gen_log "--- No se genero el archivo de control ${BKPSTAT_TMP}"
		exit 10
	fi
	STATUS=`cat ${BKPSTAT_TMP}`
	if [ ${STATUS} -ne 0 ]
	then
		gen_log "--- Verificar TS en modo BEGIN BACKUP en instancia ${INSTANCE}"
		exit 10
	fi
	rm -f ${BKPSTAT_TMP}
done

exit 0



