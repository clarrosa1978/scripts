set -x
##############################################################################
#
# Genera el puntero de TS en proceso, a partir de la lista auxiliar de TS.
#
#
# exit status:
#    0  - OK
#    1  - OK. (no hay mas TS para procesar)
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  27/11/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

BKP_LOG=${3}
TS_LIST=${4}
TS_PROC=${5}

if [ ! -f ${TS_LIST}.aux ]
then
	gen_log "--- Lista auxiliar de TS inexistente"
	gen_log "--- Se aborta el backup"
	exit 10
fi

LINES=`wc -l ${TS_LIST}.aux | awk '{print $1}'`
if [ ${LINES} -ge 1 ]
then
	if [ -f ${TS_PROC} ]
	then
		cp -pf ${TS_PROC} ${TS_PROC}.bkp
		diff ${TS_PROC} ${TS_PROC}.bkp
		if [ $? != 0 ]
		then
			gen_log "--- No se pudo hacer copia del puntero de TS en proceso"
			exit 10
		fi
		rm -f ${TS_PROC}
		if [ -f ${TS_PROC} ]
		then
			gen_log "--- No se pudo borrar el puntero de TS en proceso"
			exit 10
		fi
	fi
	head -20 ${TS_LIST}.aux > ${TS_PROC}
	if [ ! -s ${TS_PROC} ]
	then
		gen_log "--- No se pudo generar el puntero de TS en proceso"
		exit 10
	fi
	rm -f ${TS_PROC}.bkp
	exit 0
else
	gen_log "Fin de lista de TS"
	exit 1
fi



