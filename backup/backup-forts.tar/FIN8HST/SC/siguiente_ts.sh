set -x
##############################################################################
#
# Actualiza la lista auxiliar de TS para que apunte al siguiente TS a
# procesar.
#
#
# exit status:
#    0  - OK
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  29/11/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

BKP_LOG=${3}
TS_LIST=${4}

if [ ! -s ${TS_LIST}.aux ]
then
	gen_log "--- No existe la lista auxiliar de TS"
	gen_log "--- Se aborta el backup"
	exit 10
fi

rm -f ${TS_LIST}.tmp
if [ -f ${TS_LIST}.tmp ]
then
	gen_log "--- No se pudo borrar la lista auxiliar temporal de TS"
	exit 10
fi

tail +21 ${TS_LIST}.aux > ${TS_LIST}.tmp
if [ ! -f ${TS_LIST}.tmp ]
then
	gen_log "--- No se pudo generar la lista auxiliar temporal de TS"
	exit 10
fi

cp -pf ${TS_LIST}.aux ${TS_LIST}.bkp

diff ${TS_LIST}.aux ${TS_LIST}.bkp
if [ $? != 0 ]
then
	gen_log "--- No se pudo hacer copia de la lista auxiliar de TS"
	exit 10
fi

rm -f ${TS_LIST}.aux
if [ -f ${TS_LIST}.aux ]
then
	gen_log "--- No se pudo borrar la lista auxiliar de TS"
	exit 10
fi

mv -f ${TS_LIST}.tmp ${TS_LIST}.aux

if [ ! -f ${TS_LIST}.aux ]
then
	gen_log "--- No se pudo generar la lista auxiliar de TS"
	exit 10
fi

rm -f ${TS_LIST}.bkp

exit 0



