#!/usr/bin/ksh
set -x
##############################################################################
#
# Genera las listas completa y auxiliar, de TS a procesar en el backup.
# La lista auxiliar de TS es generada agregandole al comienzo el nombre
# @LISTA__CTL__LOG , que sera interpretado por los scripts genera_lista_ts.sh y
# desmarca_ts.sh , para que traten a este nombre de forma diferente a un TS, ya
# que este corresponde a la lista de control files y redolgs activos de la
# base de datos.
#
#
# exit status:
#    0  - OK
#    10 - Ver mensaje de error.
#
#
# Cesar Lopez  -  22/11/2002
#
##############################################################################

function gen_log {
HMS=`date +%H:%M:%S`
echo "${HMS} - ${1}" >> ${BKP_LOG}
}

APP=${1}
BKP_LOG=${3}
TS_LIST=${4}
ORA_USR_LIST=${19}

gen_log "Generando lista de TS"

> ${TS_LIST}
if [ $? != 0 ]
then
	gen_log "--- No se pudo inicializar la lista de TS"
	exit 10
fi

> ${TS_LIST}.aux
if [ $? != 0 ]
then
	gen_log "--- No se pudo inicializar la lista auxiliar de TS"
	exit 10
fi

for i in `cat ${ORA_USR_LIST} |grep -v ^#`
do
	ORA_USR=`echo ${i} |cut -f1 -d:`
	INSTANCE=`echo ${i} |cut -f2 -d:`
	BKP_TYPE=`echo ${i} |cut -f3 -d:`
	if [ ! -s ~${ORA_USR}/backup/tbsMgr.sh ]
	then
		gen_log "--- No existe el script ~${ORA_USR}/backup/tbsMgr.sh"
		exit 10
	fi
	su - ${ORA_USR} -c "export ORACLE_SID=${INSTANCE}; ~${ORA_USR}/backup/tbsMgr.sh ${BKP_TYPE}"
	STATUS=$?
	if [ ${STATUS} != 0 ]
	then
		gen_log "--- Error en ejecucion del tbsMgr.sh  -  status: ${STATUS}"
		exit 10
	fi
	if [ ! -s ~${ORA_USR}/backup/listas/lTbspc4bkp.asc ]
	then
		gen_log "--- No se pudo generar la lista de TS de la instancia ${INSTANCE}"
		exit 10
	fi
	echo "${ORA_USR}:${INSTANCE}:@LISTA__CTL__LOGS" >> ${TS_LIST}
	for TS in `cat ~${ORA_USR}/backup/listas/lTbspc4bkp.asc`
	do
		echo "${ORA_USR}:${INSTANCE}:${TS}" >> ${TS_LIST}
	done
done

sort -t: ${TS_LIST} > ${TS_LIST}.aux

gen_log "Lista de TS generada OK"

exit 0



