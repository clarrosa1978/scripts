/*#############################################################################
# Autor..............: TECNOLOGIA (C.A.S)                                     #
# Objetivo...........: Compruebar si DBLINK se conecta a la base ENVIOS o     #
#                      CTEFTE                                                 #
# Nombre del programa: comunicadblnk.sql                                      #
# Descripcion........: Realiza un select sysdate, si devuelve la fecha del    #
#                      sistema, la comunicacion esta OK                       #
# Modificacion.......: 15/04/2003                                             #
#############################################################################*/

set head off
select sysdate from dual@envios; 
quit
