/*#############################################################################
# Autor..............: TECNOLOGIA (C.A.S)                                     #
# Objetivo...........: Chequear si existe DBLINK                              #
# Nombre del programa: existedblnk.sql                                        #
# Descripcion........: Verifica la existencia del dblink ingresado como       #
#                      parametro                                              #
# Modificacion.......: 15/04/2003                                             #
#############################################################################*/

set head off
set verify off
select count(1) from all_db_links where DB_LINK = '&&1' and USERNAME = '&&2';
quit
