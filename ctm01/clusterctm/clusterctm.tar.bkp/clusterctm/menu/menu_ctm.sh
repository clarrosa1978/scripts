#!/usr/bin/ksh 
#trap "" 2
# MAIN
${MENU_CTM}/menu/dynamic_menu.sh  menu/menu01.txt
