#!/bin/ksh
. ${MENU_CTM}/funciones/dynamic_menu.var
. ${MENU_CTM}/funciones/funciones.lib
. ${MENU_CTM}/funciones/funciones_ecs.lib
. ${MENU_CTM}/funciones/funciones_ctm.lib
stop_local_database_ecs
stop_local_database_ctm
