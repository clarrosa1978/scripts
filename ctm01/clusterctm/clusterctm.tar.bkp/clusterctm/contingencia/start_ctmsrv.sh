#!/bin/ksh
. ${MENU_CTM}/funciones/dynamic_menu.var
. ${MENU_CTM}/funciones/funciones.lib
. ${MENU_CTM}/funciones/funciones_ctm.lib
start_local_ctm
start_local_ctm_ca
